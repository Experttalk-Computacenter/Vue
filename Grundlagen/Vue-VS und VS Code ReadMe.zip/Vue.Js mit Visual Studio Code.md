# Vue.Js mit Visual Studio Code

# Voraussetzungen
- [NodeJS] installieren
- [Visual Studio Code] installieren

# Visual Studio Code
## Terminal öffnen 
- Benutze den Keyboard Shortcut  **Strg + Shift + ö** oder
- **Terminal > New Terminal**
Überprüfe, ob Node.Js installiert wurde
``` console
> node -v
```
## Projekt erstellen 

  > Empfehlung bei der *root* anzufangen und einen neuen Ordner erstellen, z.B. *"vueapp"*
 ```
 > cd /
 > mkdir vueapp
 ```
Wechseln in den Projektordner.
```
> cd vueapp
```
## Vue-CLI
Vue-CLI in das Projekt einbinden
```
C:\vueapp> npm install -g @vue/cli
```
> -g oder -global: Global installierten Pakete fallen Module in {prefix}/lib/node_modules und ausführbare Dateien in setzen {prefix}/bin , wo {prefix} in der Regel so etwas wie ist /usr/local . Die Installation eines globalen Moduls bedeutet, dass seine Binärdateien in Ihrer Umgebungsvariablen PATH enden. Normalerweise sollten Sie ein globales Modul installieren, wenn es sich um ein Befehlszeilentool oder um etwas handelt, das Sie in Ihrer Shell verwenden möchten. 

Überprüfe die Vue Version
```
C:\vueapp>vue --version
```
Bei einem *"about_Execution_Policies"*-Error:
- Schließe VS Code und öffne VS Code erneut als Administrator
> **Rechter-Mausklick"** > **Als Admistrator ausführen**
- Öffne das Terminal
```
> set-exucutionpolicy unrestricted
> cd \
C:\> cd vueapp
C:\vueapp>vue --version
```

# Vue Project erstellen
```
C:\vueapp>vue create helloworld
```

### Projekt Struktur - Default
``` bash
Vue Projekt
│   README.md
│   package-lock.json
│   package.json
│   babel.config.js
│   .gitignore
└───node_modules
│   
└───public
│     │   favivon.ico
│     │   index.html
└───src
│     └───assets
│     │   logo.png
│     └───components
│     │   HelloWorld.vue
│   App.vue
│   main.js
```


   [Visual Studio Code]: <https://code.visualstudio.com/download>
   [NodeJs]: <https://nodejs.org/de/download/>

