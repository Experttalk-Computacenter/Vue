# Schnellstart: Erstellen Ihrer ersten Vue.js-App mit Visual Studio

## Step-by-Step Anleitung - [Vue.Js mit Visual Studio]
### Voraussetzung

  - Visual Studio und die Workload für die Node.js-Entwicklung installieren:
  navigieren Sie zu **Tools > Tools und Features** abrufen… . Dadurch wird der Visual Studio-Installer geöffnet. Klicken Sie auf die Workload **Node.js-Entwicklung** und anschließend auf **Ändern**.
![node.js-entwicklung](https://docs.microsoft.com/de-de/visualstudio/ide/media/quickstart-nodejs-workload.png?view=vs-2019)
  - die LTS-Version von der [Node.js]-Website installieren
  > **Information**: Wird die installierte Runtime nicht erkannt, können Sie das Projekt so konfigurieren, dass auf der Eigenschaftenseite auf die installierte Runtime verwiesen wird (klicken Sie hierzu nach dem Erstellen des Projekts mit der rechten Maustaste auf den Projektknoten, wählen Sie Eigenschaften aus, und legen Sie den Node.exe-Pfad fest). Sie können eine globale Installation von Node.js verwenden oder in jedem Ihrer Node.js-Projekte den Pfad zu einem lokalen Interpreter angeben.


# Erstellen eines Projektes!

  Zunächst müssen Sie ein Projekt für die Vue.js-Webanwendung erstellen.
1. Wenn die Node.js-Runtime nicht bereits installiert ist, installieren Sie die LTS-Version über die Node.js-Website.
2. Öffnen Sie Visual Studio.
3. Erstellen Sie ein neues Projekt.

Drücken Sie **ESC**, um das Startfenster zu schließen. Geben Sie **STRG+Q** ein, um das Suchfeld zu öffnen, geben Sie **Grundlegende Vue.js** ein, und wählen Sie dann **Grundlegende Vue.js-Webanwendung** (entweder JavaScript oder TypeScript) aus. Geben Sie im Dialogfeld, das nun angezeigt wird, den Namen **basic-vuejs** ein, und wählen Sie dann **Erstellen** aus.
  ![basic vue.js](https://docs.microsoft.com/de-de/visualstudio/javascript/media/vs-2019/vuejs-template.png?view=vs-2019)

Wenn die Projektvorlage Grundlegende Vue.js-Webanwendung nicht angezeigt wird, müssen Sie die Workload für die Node.js-Entwicklung hinzufügen. Ausführliche Anweisungen dazu finden Sie in den [Voraussetzungen](#Voraussetzung_3).

Visual Studio erstellt daraufhin das neue Projekt. Das neue Projekt wird im Projektmappen-Explorer geöffnet (im rechten Bereich).
4. Überprüfen Sie während der Installation des npm-Pakets, das für die Anwendung erforderlich ist, im Fenster „Ausgabe“ (unterer Bereich) den Fortschritt.
5. Öffnen Sie im Projektmappen-Explorer den **npm**-Knoten, und stellen Sie sicher, dass alle aufgeführten npm-Pakete installiert wurden.

Wenn Pakete fehlen (Ausrufezeichensymbol), klicken Sie mit der rechten Maustaste auf den **NPM**-Knoten, und wählen Sie **Fehlende NPM-Pakete installieren** aus.

## Installieren der fehlenden NPM-Pakete per Konsole
Öffnen Sie die Konsole in Visual Studio mit dem Befehl **Extras > NuGet-Paket-Manager > Paket-Manager-Konsole**. Die Konsole ist ein Visual Studio-Fenster, das beliebig angeordnet und positioniert werden kann.
```sh
PM> npm install
```
# Ausführung der Anwendung
Drücken Sie **STRG+F5**, oder klicken Sie auf **Debuggen > Starten ohne Debugging**, um die Anwendung auszuführen.

In der Konsole wird Ihnen die Meldung Development Server wird gestartet angezeigt.

Anschließend wird die App in einem Browser geöffnet.

Wenn die ausgeführte App nicht angezeigt wird, aktualisieren Sie die Seite.
![vue start](https://docs.microsoft.com/de-de/visualstudio/javascript/media/vuejs-running-app.png?view=vs-2019)

# Projekt Struktur - Default
``` bash
Vue Projekt
│   README.md
│   package-lock.json
│   package.json
│   babel.config.js
│   .gitignore
└───node_modules
│   
└───public
│     │   favivon.ico
│     │   index.html
└───src
│     └───assets
│     │   logo.png
│     └───components
│     │   HelloWorld.vue
│   App.vue
│   main.js
```







   [Vue.Js mit Visual Studio]: <https://docs.microsoft.com/de-de/visualstudio/javascript/quickstart-vuejs-with-nodejs?view=vs-2019>
   [Node.js]: <https://nodejs.org/de/download/>
   
